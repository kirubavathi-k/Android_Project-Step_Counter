package com.vardhancreations.stepcounter;
import static android.content.Context.MODE_PRIVATE;

import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import java.io.*;
import java.util.Locale;

public class ProfileFragment extends Fragment {
    DBHelper DB;
    View layoutView;
    String nameFrom,email,phone,address;
    int followersCount,followingCount;
    TextView tv_name,tv_address,tvEmail,tvPhone,tvFollowers,tvFollowing;
    public ProfileFragment(){
        // require a empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        DB=new DBHelper(getContext());
        layoutView= inflater.inflate(R.layout.fragment_profile, container, false);
        SharedPreferences preferences = getActivity().getSharedPreferences("datastore", MODE_PRIVATE);
        String name = preferences.getString("Name", "No name was stored");
        Cursor profileData = DB.getDetails(name);
        if(profileData.getCount()==0){
            Toast.makeText(getContext(), "No Entry Exists", Toast.LENGTH_SHORT).show();
        }
//                StringBuffer buffer =new StringBuffer();
        while(profileData.moveToNext()){
            nameFrom = profileData.getString(0);
            email = profileData.getString(2);
            phone = profileData.getString(3);
            address = profileData.getString(4);
            followersCount = profileData.getInt(5);
            followingCount = profileData.getInt(6);
        }
        tv_name=(TextView) layoutView.findViewById(R.id.tv_name);
        tv_address=(TextView) layoutView.findViewById(R.id.tv_address);
        tvEmail =(TextView) layoutView.findViewById(R.id.email);
        tvPhone=(TextView) layoutView.findViewById(R.id.phone);
        tvFollowers=(TextView)layoutView.findViewById(R.id.userfollowers);
        tvFollowing=(TextView)layoutView.findViewById(R.id.userfollowing);

        tv_name.setText(nameFrom);

        tvEmail.setText(email);
        tvPhone.setText(phone);
        tv_address.setText(address);
        tvFollowers.setText(followersCount+"");
        tvFollowing.setText(followingCount+"");
        return layoutView;
    }
}
