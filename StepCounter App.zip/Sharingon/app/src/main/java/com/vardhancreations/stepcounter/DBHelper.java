package com.vardhancreations.stepcounter;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.function.BinaryOperator;

public class DBHelper extends SQLiteOpenHelper {
    public DBHelper(Context context) {
        super(context, "UserData.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase DB) {
        DB.execSQL("create Table users(name TEXT primary key,password TEXT,email TEXT,phone TEXT,address TEXT,followers NUMBER,following NUMBER,steps NUMBER)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase DB, int i, int i1) {
        DB.execSQL("drop Table if exists users");

    }
    public Boolean insertUserData(String name,String password,String email,String phone,String address,int followers,int following,int steps){
        SQLiteDatabase DB=this.getWritableDatabase();
        ContentValues contentValues= new ContentValues();
        contentValues.put("name",name);
        contentValues.put("password",password);
        contentValues.put("email",email);
        contentValues.put("phone",phone);
        contentValues.put("address",address);
        contentValues.put("followers",followers);
        contentValues.put("following",following);
        contentValues.put("steps",steps);
        long result=DB.insert("users",null,contentValues);
        if(result==-1){
            return false;

        }else {
            return true;
        }

    }
    public Boolean updateSteps(String name,int steps){
        SQLiteDatabase DB=this.getWritableDatabase();
        ContentValues contentValues  = new ContentValues();
        contentValues.put("steps",steps);
        Cursor cursor = DB.rawQuery("select * from users where name=?",new String[]{name});
        if(cursor.getCount()>0) {
            long result = DB.update("users", contentValues, "name=?", new String[]{name});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        }
        else{
            return false;
        }
    }
    public Boolean updateUserData(String name,String email,String phone){
        SQLiteDatabase DB=this.getWritableDatabase();
        ContentValues contentValues= new ContentValues();
        // contentValues.put("name",name);
        contentValues.put("email",email);
        contentValues.put("phone",phone);
        Cursor cursor=DB.rawQuery("select * from users where name=?",new String[]{name});
        if(cursor.getCount()>0) {
            long result = DB.update("users", contentValues, "name=?", new String[]{name});
            if (result == -1) {
                return false;

            } else {
                return true;
            }
        }else
        {
            return false;
        }

    }
    public void updateFollowers(String name){
        SQLiteDatabase DB=this.getWritableDatabase();
        ContentValues contentValues= new ContentValues();
        int followers = name.length();
        int following = name.length()-2;
        // contentValues.put("name",name);
        contentValues.put("followers",followers);
        contentValues.put("following",following);
        Cursor cursor=DB.rawQuery("select * from users where name=?",new String[]{name});
        if(cursor.getCount()>0) {
            long result = DB.update("users", contentValues, "name=?", new String[]{name});
        }

    }
    public Cursor getPassword(String name){
        SQLiteDatabase DB = this.getReadableDatabase();
        Cursor cursor = DB.rawQuery("select * from users where name=?",new String[]{name});
        return cursor;
    }
    public Cursor getDetails(String name){
        SQLiteDatabase DB = this.getReadableDatabase();
        Cursor cursor = DB.rawQuery("select * from users where name=?",new String[]{name});
        return cursor;
    }

    public Boolean deleteData(String name) {
        SQLiteDatabase DB = this.getWritableDatabase();

        Cursor cursor = DB.rawQuery("select * from users where name=?", new String[]{name});
        if (cursor.getCount() > 0) {
            long result = DB.delete("users","name=?",new String[]{name});
            if (result == -1) {
                return false;

            } else {
                return true;
            }
        } else {
            return false;
        }
    }
    public Cursor getData() {
        SQLiteDatabase DB = this.getWritableDatabase();

        Cursor cursor = DB.rawQuery("select * from users",null);
        return cursor;
    }
}

